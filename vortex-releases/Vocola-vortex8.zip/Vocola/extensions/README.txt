Place your Vocola 2 extension files in this directory.

See http://vocola.net/v2/UsingExtensions.asp for more information.

As of Vocola 2.8.7, the following standard extensions come preinstalled:
    Clipboard, Date, Env, Keys, Subprocess,  Variable, and Vocola

A starter version of the DragonProxy is also provided; it can switch
back and forth between SendDragonKeys and SendInput for default
keystrokes as well as print out Dragon actions when verbose mode is
turned on.
