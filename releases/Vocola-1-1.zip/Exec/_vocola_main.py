# "Built-in" voice commands for Vocola

import sys
import os               # access to file information
import os.path          # to parse filenames
import time             # print time in messages
import natlink
from stat import *      # file statistics
from natlinkutils import *

class ThisGrammar(GrammarBase):

    gramSpec = """
        <1> exported = Load [Voice] Commands;
        <2> exported = Edit [Voice] Commands;
        <3> exported = Edit Machine [Voice] Commands;
        <4> exported = Edit Global [Voice] Commands;
        <5> exported = Edit Global Machine [Voice] Commands;
    """
    
    def initialize(self):
        self.load(self.gramSpec)
        self.activateAll()

    def gotBegin(self,moduleInfo):
        self.currentModule = moduleInfo
        if (moduleInfo == ("","",0)):
            print time.strftime('%a %H:%M', time.localtime(time.time())), 'Vocola cannot determine application; app-specific commands disabled'

    # "Load Commands" -- process all Vocola files 
    # (from NatLink/Vocola/Commands into NatLink/MacroSystem)
    def gotResults_1(self, words, fullResults):
        self.setNames()
        perl = '"Exec\\vcl2py.exe Commands ' + self.NatLinkFolder + '"'
        #perl = '"perl Exec\\vcl2py.pl Commands ' + self.NatLinkFolder + '"'
        call = 'ShellExecute ' + perl + ', 6, "' + self.VocolaFolder + '"'
        natlink.execScript(call)

    # "Edit Commands" -- open command file for current application
    def gotResults_2(self, words, fullResults):
        self.setNames()
        file = self.commandFolder + self.module + '.vcl'
        comment = 'Voice commands for ' + self.module
        self.openFile(file, comment)

    # "Edit Machine Commands" -- open command file for current app & machine
    def gotResults_3(self, words, fullResults):
        self.setNames()
        file = self.commandFolder + self.module + '@' + self.machine + '.vcl'
        comment = 'Voice commands for ' + self.module + ' on ' + self.machine
        self.openFile(file, comment)

    # "Edit Global Commands" -- open global command file
    def gotResults_4(self, words, fullResults):
        self.setNames()
        file = self.commandFolder + '_vocola.vcl'
        comment = 'Global voice commands'
        self.openFile(file, comment)

    # "Edit Global Machine Commands" -- open global command file for machine
    def gotResults_5(self, words, fullResults):
        self.setNames()
        file = self.commandFolder + '_vocola@' + self.machine + '.vcl'
        comment = 'Global voice commands on ' + self.machine
        self.openFile(file, comment)

    def setNames(self):
        # Get the application name by stripping the directory and extension
        self.module = string.lower(os.path.splitext(
            os.path.split(self.currentModule[0])[1])[0])
        self.machine = string.lower(os.environ['COMPUTERNAME'])
        self.NatLinkFolder = os.path.split(
            sys.modules['natlinkmain'].__dict__['__file__'])[0]
        self.VocolaFolder = self.NatLinkFolder + '\\..\\Vocola\\'
        self.commandFolder = self.VocolaFolder + 'Commands\\'

    def openFile(self, filename, comment):
        try: os.stat(filename)
        except OSError:  # file not found -- create one
            new = open(filename, 'w')
            new.write('# ' + comment + '\n\n')
            new.close()
        # Open the file (using the application associated with ".vcl")
        natlink.execScript('ShellExecute "cmd /c ' + filename + '", 6')

thisGrammar = ThisGrammar()
thisGrammar.initialize()

def unload():
    global thisGrammar
    if thisGrammar: thisGrammar.unload()
    thisGrammar = None
