# vcl2py:  Convert Vocola voice command files to NatLink Python "grammar"
#          classes implementing the voice commands
#
# Usage:  perl vcl2py.pl input_folder output_folder
#
# This file is copyright (c) 2002 by Rick Mohr. It may be redistributed 
# in any way as long as this copyright notice remains
#
# 05/03/2002 Version 1.1
# 05/03/2002 Handle application names containing '_'
# 05/03/2002 Convert '\' to '\\' early to avoid quotewords bug
# 02/18/2002 Version 0.9
# 12/08/2001 convert e.g. "{Tab_2}" to "{Tab 2}"
#            expand in-string references (e.g. "{Up $1}")
# 03/31/2001 Detect and report unbalanced quotes
# 03/06/2001 Improve error checking for complex menus
# 02/24/2001 Change name to Vocola
# 02/18/2001 Handle terms containing an apostrophe
# 02/06/2001 Machine-specific command files
# 02/04/2001 Error on undefined variable or reference out of range
# 08/22/2000 First usable version

# Style notes:
#   Global variables are capitalized (e.g. $Definitions)
#   Local variables are lowercase (e.g. $in_folder)

use Text::ParseWords;    # for quotewords

# ---------------------------------------------------------------------------
# Main control flow

$VocolaVersion = "1.1";
$Debug = 0;  # 0 = no info, 1 = show statements, 2 = detailed info
$| = 1;      # flush output after every print statement
&convert_folder;

sub convert_folder    # Convert each .vcl file to a .py file
{
    my ($in_folder, $out_folder);
    if (@ARGV == 2) {
        $in_folder = $ARGV[0];
        $out_folder = $ARGV[1];
    } else {
        die "vcl2py: Requires 2 command line arguments\n";
    }
    opendir FOLDER, "$in_folder" or die "Couldn't open folder '$in_folder'\n";
    my $log_file = "$in_folder\\vcl2py_log.txt";
    open LOG, ">$log_file" or die "$@ $log_file";
    $Show_log = $Debug > 0;
    my $machine = lc($ENV{COMPUTERNAME});

    foreach (readdir FOLDER)
    {
        if (/^(.+)\.vcl$/) {
            my $in_file = lc($1);
            # skip machine-specific files for different machines
            next if ($in_file =~ /\@(.+)/ and $1 ne $machine);
            my $out_file = $in_file;
            $out_file =~ s/[\@]/_/;
            $out_file =~ s/[-]/_/;

            # The module name is used below to implement application-specific 
            # commands in the output Python
            #if ($out_file =~ /^(.+?)_.*/) {$Module_name = $1}
            #else                          {$Module_name = $out_file}
            $Module_name = lc($out_file);
            $in_file = "$in_folder/$in_file.vcl";
            $out_file = "$out_folder/$out_file.py";
            open IN, "<$in_file" or die "$@ $in_file";
            print LOG "Converting $in_file\n";
            convert_file($out_file);
            close IN;
        }
    }
    close LOG;
    system("\"$log_file\"") if $Show_log;
}

sub convert_file
{
    my $out_file = shift;
    %Definitions = ();
    $Has_error = 0;
    $File_empty = 1;
    $Line_number = 1;
    if ($Debug>=1) {print LOG "\n==============================\n\n";}
    my $text = &read_input;
    my @statements = parse_statements($text);

    #print_statements (*LOG, @statements);
    if ($Has_error) {
        print LOG "  File not converted.\n";
        $Show_log = 1;
        return;
    }
    if ($File_empty) {
        print LOG "  No commands in file; file not converted.\n";
        return;
    }
    emit_output($out_file, @statements);
}

# ---------------------------------------------------------------------------
# Parsing routines
#
# The following grammar defines the Vocola language:
# (note that a "menu" is called an "alternative set" in the documentation)
#
#     statements = (context | top_command | definition)*
#
#        context = chars* ':'
#     definition = variable ':=' menu_body ';'
#    top_command = terms '=' action* ';'
#
#        command = terms ['=' action*]
#          terms = (term | '[' simple_term ']')+
#           term = simple_term | range | menu
#    simple_term = word | variable
#         action = word | call | reference
#
#           menu = '(' menuBody ')'
#       menuBody = command ('|' command)*
#
#           word = chars | '"' chars '"' |  "'" chars "'"
#       variable = '<' variableName '>'
#          range = number '..' number
#      reference = '$' number
#           call = functionName '(' arguments ')'
#      arguments = [argument (',' argument)*]
#       argument = word | reference
#
# The parser works as follows:
#     1) Strip comments
#     2) Find statement segments by slicing at major delimiters (: ; :=)
#     3) Parse each segment using recursive descent
#
# The parse tree is built from three kinds of nodes (statement, term, 
# and action), using the following fields:
#
# statement: 
#    TYPE - command/definition/context
#    command:
#       NAME    - unique number
#       TERMS   - list of "term" structures
#       ACTIONS - list of "action" structures
#    definition:
#       NAME    - name of variable being defined
#       MENU    - "menu" structure defining alternatives
#    context:
#       TEXT    - string to use in context matching
# 
# term:
#    TYPE   - word/variable/range/menu
#    NUMBER - sequence number of this term
#    word:
#       TEXT     - text defining the word(s)
#       OPTIONAL - is this word optional
#    variable:
#       TEXT     - name of variable being referenced
#       OPTIONAL - is this variable optional
#    range:
#       FROM     - start number of range
#       TO       - end number of range
#    menu:
#       COMMANDS - list of "command" structures defining the menu
#       
# action:
#    TYPE - word/reference/call
#    word:
#       TEXT      - keystrokes to send
#    reference:
#       TEXT      - number of variable referenced
#    call:
#       TEXT      - name of function called
#       ARGUMENTS - list of words or references, to be passed in call

sub read_input     # return string, stripped of comments 
{
    my @strings;
    while (<IN>) {
        if (/\#/) {
            # Line may contain a comment
            my @chunks = quotewords("\#", "delimiters", $_);
            push (@strings, $chunks[0]) if $chunks[0] ne "\#";
            push (@strings, "\n"      ) if @chunks > 1;
        } else {
            push (@strings, $_);
        }
    }
    join ('', @strings);
}

sub parse_statements    # statements = (context | top_command | definition)*
{
    my $text = shift;
    my (@statements, $statement);
    my $statement_count = 1;
    @Forward_references = ();

    # For python output we'll need to convert '\' to '\\'.  Do it up front so
    # quotewords won't miss '\;', e.g. in 'Kill White Space = {Esc}\;'
    $text =~ s.\\.\\\\.g;

    # Find statement segments by slicing at major delimiters (: ; :=)
    my @segments = quotewords(":=|:\\s|;", "delimiters", ($text));

    # Check for unbalanced quotes (because quotewords gives up )-:
    if (not @segments and my $line = has_unbalanced_quote($text[0])) {
        print LOG "  Error:  Unbalanced quote";
        print LOG ", possibly near line $line" unless $line == -1;
        print LOG "\n";
        $Has_error = 1;
        return;
    }

    # Put statement segments in the global argument array @_
    # Segments will be removed as they are parsed by parse_ routines

    @_ = @segments;
    while (@_ > 1)  # while segment array is not empty...
    {
        eval { $statement = (&parse_context or
                             &parse_definition or
                             &parse_top_command)
               };
        if    ($@)             {error($@)}  # Catch calls to "die"
        elsif (not $statement) {error("Illegal statement: '@_[0]'\n"); shift}
        else {
            if ($statement->{TYPE} eq "definition") {
                my $name = $statement->{NAME};
                if ($Definitions{$name}) {
                    error("Ignoring redefinition of <$name>\n");
                } else {
                    $Definitions{$name} = $statement;
                }
            } elsif ($statement->{TYPE} eq "command") {
                $statement->{NAME} = $statement_count++;
            }
            push (@statements, $statement);
        }
    }
    if (@_[0] =~ /\S/) {error("Missing final delimiter: '@_[0]'\n")}

    # Prepend a "global" context statement if necessary
    if ($statements[0]->{TYPE} ne "context") {
        $context = parse_context(": ");
        unshift(@statements, $context);
    }
    &check_forward_references;
    return @statements;
}    

sub parse_context    # context = word* ':'
{
    if ($_[0] =~ /^:\s$/ or $_[1] =~ /^:\s$/) {
        my $statement = {};
        $statement->{TYPE} = "context";
        if ($_[1] =~ /:\s/) {
            &shift_clause;
            /^\s*(.*)$/;
            $statement->{TEXT} = $1;
        } else {
            &shift_delimiter;
            $statement->{TEXT} = "";
        }
        if ($Debug>=1) {print_context (*LOG, $statement)}
        return $statement;
    }
}

sub parse_definition    # definition = variable ':=' menu_body ';'
{
    if ($_[1] eq ":=" and $_[3] eq ";") {
        my $statement = {};
        $statement->{TYPE} = "definition";

        &shift_clause;
        /^\s*<(.*)>\s*$/ or die "Illegal variable: '$_'\n";
        $statement->{NAME} = $1;

        &shift_clause;
        $statement->{MENU} = &parse_menu_body;
        #my $menu = &parse_menu_body;
        &ensure_empty;
        #if ($menu->{TYPE} eq "menu") {verify_referenced_menu($menu)};
        #$statement->{MENU} = $menu;
        if ($Debug>=1) {print_definition (*LOG, $statement)}
        return $statement;
    }
}

sub parse_top_command    # top_command = terms '=' action* ';'
{
    if ($_[1] eq ";") {
        &shift_clause;
        error("Missing '=' in command\n") unless /=/;
        my $statement = &parse_command;
        &ensure_empty;
        $statement->{TYPE} = "command";
        $File_empty = 0;
        if ($Debug>=1) {print_command (*LOG, $statement); print LOG "\n"}
        return $statement;
    }
}

sub parse_command    # command = terms ['=' action*]
{
    my $command = {};
    $command->{TERMS} = &parse_terms;

    # Count variable terms for range checking in &parse_reference
    @Command_variables = get_variable_terms($command);

    if (/\G\s*=/gc) {
        $command->{ACTIONS} = &parse_actions;
    }
    return $command;
}

sub parse_terms    # terms = (term | '[' simple_term ']')+
{
    my (@terms, $term);
    my $all_optional = 1;
    while (1) {
        my $optional = /\G\s*\[/gc;
        if ($optional) {
            $term = &parse_simple_term;
            if    (not $term)       {die "Expected term after '['\n"}
            elsif (not /\G\s*\]/gc) {die "Missing ']'\n"}
        } else {
            $term = &parse_term;
        }
        if ($term) {
            $term->{OPTIONAL} = $optional;
            $all_optional = 0 if not $optional;
            push (@terms, $term);
        } elsif (@terms and not $all_optional) {
            return combine_terms(@terms);
        } else {
            die "A command must have at least one non-optional term\n";
        }
    }
}

sub combine_terms    # Combine adjacent "word" terms; number resulting terms
{
    my @terms;
    my $term_count = 0;
    while (@_) {
        my $term = shift;
        if (&is_required_word($term)) {
            while (@_ and &is_required_word) {
                $term->{TEXT} .= " " . shift->{TEXT};
            }
        }
        $term->{NUMBER} = $term_count++;
        push (@terms, $term);
    }
    return \@terms;
}

sub is_required_word {@_[0]->{TYPE} eq "word" and not @_[0]->{OPTIONAL}}

sub parse_term    #  term = simple_term | range | menu
                  # range = number '..' number
                  #  menu = '(' menuBody ')'
{
    my $term;
    if (/\G\s*\(/gc) {
        $term = &parse_menu_body;
        if (not /\G\s*\)/gc) {die "Missing ')'\n"}
        if ($Debug>=2) {print LOG "Found menu:  "; 
                        print_menu (*LOG, $term); print LOG "\n"}
    } elsif (/\G\s*(\d*)\.\.(\d*)/gc) {
        $term = {};
        $term->{TYPE} = "range";
        $term->{FROM} = $1;
        $term->{TO}   = $2;
        if ($Debug>=2) {print LOG "Found range:  $1..$2\n"}
    } else {
        $term = &parse_simple_term;
    }
    return $term;
}

sub parse_simple_term    # simple_term = words | variable
                         #    variable = '<' variableName '>'
{
    if (/\G\s*<(.*?)>/gc) {
        my $term = {};
        $term->{TYPE} = "variable";
        $term->{TEXT} = $1;
        if ($Debug>=2) {print LOG "Found variable:  <$1>\n"}
        add_forward_reference($1) unless $Definitions{$1};
        return $term;
    } else {
        return &parse_word;
    }
}

sub parse_menu_body    # menuBody = command ('|' command)*
{
    my $menu = {};
    my @commands;
    while (1) {
        my $command = &parse_command;
        if (not $command) {die "Missing or invalid command in menu\n"}
        push (@commands, $command);
        last unless /\G\s*\|/gc;
    }
    $menu->{TYPE} = "menu";
    $menu->{COMMANDS} = \@commands;
    return $menu;
}

sub parse_actions    # action = words | call | reference
{
    my @actions;
    while (my $action = (&parse_reference or &parse_call or &parse_word)) {
        if ($action->{TYPE} ne "word" || $action->{TEXT} eq "") {
            push (@actions, $action);
        } else {
            # convert e.g. "{Tab_2}" to "{Tab 2}"
            $action->{TEXT} =~ s/\{(.*?)_(.*?)\}/\{$1 $2\}/g;

            # expand in-string references (e.g. "{Up $1}")
            while ($action->{TEXT} =~ /\G(.*?[^\\])\$(\d+)/gc) {
                push (@actions, create_word_node($1, 1)) if $1;
                push (@actions, create_reference_node($2));
            }
            if ($action->{TEXT} =~ /\G(.+)/gc) {
                push (@actions, create_word_node($1, 1));
            }
        }
    }
    return \@actions;
}

sub parse_reference    # reference = '$' number
{
    if (/\G\s*\$(\d+)/gc) {
        return create_reference_node($1);
    }
}

sub create_reference_node
{
    my $n = shift;
    if ($n > @Command_variables) {die "Reference '\$$n' out of range\n"}
    my $term = $Command_variables[$n - 1];
    if ($term->{TYPE} eq "menu") {verify_referenced_menu($term)};
    if ($Debug>=2) {print LOG "Found reference:  \$$n\n"}
    my $action = {};
    $action->{TYPE} = "reference";
    $action->{TEXT} = $n;
    return $action;
}

sub parse_call    # call = functionName '(' arguments ')'
{
    if (/\G\s*(\w+?)\s*\(/gc) {
        if ($Debug>=2) {print LOG "Found call:  $1()\n"}
        my $action = {};
        $action->{TYPE} = "call";
        $action->{TEXT} = $1;
        $action->{ARGUMENTS} = &parse_arguments;
        if (not /\G\s*\)/gc) {die "Missing ')'\n"}
        return $action;
    }
}

sub parse_arguments    # arguments = [argument (',' argument)*]
                       #  argument = word | reference
{
    my @arguments;
    my $argument = (&parse_reference or &parse_word);
    return unless $argument;
    while (1) {
        push (@arguments, $argument);
        last unless /\G\s*,/gc;
        $argument = (&parse_reference or &parse_word);
        if (not $argument) {die "Missing or invalid argument\n"}
    }
    return \@arguments;
}

sub parse_word    # word = chars | '"' chars '"' |  "'" chars "'"
{
    if (   /\G\s*\"([^\"]*)\"\s*/gc      # "word"
        or /\G\s*\'([^\']*)\'\s*/gc      # 'word'
        or /\G\s*([^\s=()\[\]|,]+)/gc)   #  word
    {
        return create_word_node($1, 0);
    }
}

sub create_word_node
{
    my $text = shift;
    my $substitute = shift;
    $text =~ s/\\\$/\$/g if $substitute;  # convert \$ to $
    my $term = {};
    $term->{TYPE} = "word";
    $term->{TEXT} = $text;
    if ($Debug>=2) {print LOG "Found word:  '$1'\n"}
    return $term;
}

sub ensure_empty
{
    if (/\G\s*(\S+)/gc) {
        die "Unexpected text: '$1'\n";
    }
}

# The argument list contains a string we want to parse, followed by a 
# delimiter.  Splice them both out of the list, making the string the
# current argument ($_).  Also count newlines for error reporting.

sub shift_clause
{
    $_ = $_[0] . $_[1];
    $Line_number++ while (/\G.*?\n/gc);
    $_ = shift;
    shift;
}

sub shift_delimiter 
{
    $_ = shift;
    $Line_number++ while (/\G.*?\n/gc);
}

sub error
{
    print LOG "  Error at line $Line_number:  $_[0]";
    $Has_error = 1;
}

# ---------------------------------------------------------------------------
# Check for unbalanced quotes

sub has_unbalanced_quote
{
    $_ = shift;
    my $line = 1;
    my $bad_line_guess = -1;
    while (/\G(.*?)([\'\"])(.*?)\2/gcs) {
        $line += count_lines($1);
        $bad_line_guess = $line if ($bad_line_guess == -1 and $3 =~ /=|;/);
        return $bad_line_guess if $1 =~ /[\'\"]/s;
        $line += count_lines($3);
    }
    if (/\G(.+)/gcs) {
        return $bad_line_guess if $1 =~ /[\'\"]/s;
    }
    return 0;
}

sub count_lines
{
    my $text = shift;
    my $line_count = 0;
    $line_count++ while $text =~ /\G.*?\n/gc;
    return $line_count
}

# ---------------------------------------------------------------------------
# Parse-time error checking of references

sub verify_referenced_menu
{
    my ($menu, $parent_has_actions) = @_;
    my @commands = @{ $menu->{COMMANDS} };
    for my $command (@commands) {
        my $has_actions = $parent_has_actions;
        my @actions = @{ $command->{ACTIONS} };
        if (@actions) {
            if ($parent_has_actions) {die "Actions may not be nested\n"}
            $has_actions = 1;
            # make sure no actions are references
            for my $action (@actions) {
                if ($action->{TYPE} eq "reference") {
                    die "Substitution may not contain a reference\n";
                }
            }
        }
        my @terms = @{ $command->{TERMS} };
        if (@terms > 1) {die "Alternative is too complex\n"}
        my $type = $terms[0]->{TYPE};
        if    ($type eq "menu"){verify_referenced_menu($terms[0],$has_actions)}
        elsif ($type eq "variable") {die "Alternative cannot be a variable\n"}
        elsif ($type eq "range") {
            # allow a single range with no actions
            return if (not $has_actions and @commands == 1);
            die "Alternative cannot be a range\n";
        }
    }
}

sub add_forward_reference
{
    my $forward_reference = {};
    $forward_reference->{VARIABLE} = $_[0];
    $forward_reference->{LINE_NUMBER} = $Line_number;
    push (@Forward_references, $forward_reference);
}

sub check_forward_references
{
    for my $forward_reference (@Forward_references) {
        my $variable = $forward_reference->{VARIABLE};
        if (not $Definitions{$variable}) {
            print LOG "  Error at line $forward_reference->{LINE_NUMBER}:  ";
            print LOG "Reference to undefined variable '<$variable>'\n";
            $Has_error = 1;
        }
    }
}

# ---------------------------------------------------------------------------
# Printing of data structures (for debugging)

sub print_statements
{
    my $out = shift;
    for my $statement (@_) {
        if ($statement->{TYPE} eq "context") {
            print_context ($out, $statement);
        } elsif ($statement->{TYPE} eq "definition") {
            print_definition ($out, $statement);
        } elsif ($statement->{TYPE} eq "command") {
            print $out "C$statement->{NAME}:  ";
            print_command ($out, $statement);
            print $out ";\n";
        }
    }
    print $out "\n";
}

sub print_context
{
    my ($out, $statement) = @_;
    print $out "Context:  '$statement->{TEXT}'\n";
}

sub print_definition
{
    my ($out, $statement) = @_;
    print $out "D:  <$statement->{NAME}> := ";
    print_menu ($out, $statement->{MENU});
    print $out ";\n";
}

sub print_command
{
    my ($out, $command) = @_;
    print_terms ($out, @{ $command->{TERMS} });
    if ($command->{ACTIONS}) {
        print $out " = ";
        print_actions ($out, @{ $command->{ACTIONS} });
    }
}

sub print_terms
{
    my $out = shift;
    print_term($out, shift);
    for my $term (@_) {
        print $out " ";
        print_term($out, $term);
    }
}

sub print_term
{
    my ($out, $term) = @_;
    #print $out "$term->{NUMBER}:";
    if ($term->{OPTIONAL}) {print $out "["}
    if    ($term->{TYPE} eq "word")     {print $out "$term->{TEXT}"}
    elsif ($term->{TYPE} eq "variable") {print $out "<$term->{TEXT}>"}
    elsif ($term->{TYPE} eq "menu")     {print_menu ($out, $term)}
    elsif ($term->{TYPE} eq "range") {
        print $out "$term->{FROM}..$term->{TO}";
    }
    if ($term->{OPTIONAL}) {print $out "]"}
}

sub print_menu
{
    my $out = shift;
    my @commands = @{ shift->{COMMANDS} };
    print $out "(";
    print_command ($out, shift @commands);
    for my $command (@commands) {
        print $out " | ";
        print_command ($out, $command);
    }
    print $out ")";
}

sub print_actions
{
    my $out = shift;
    print_action($out, shift);
    for my $action (@_) {
        print $out " ";
        print_action($out, $action);
    }
}

sub print_action
{
    my ($out, $action) = @_;
    if    ($action->{TYPE} eq "word")     {print $out "$action->{TEXT}"}
    elsif ($action->{TYPE} eq "reference"){print $out "\$$action->{TEXT}"}
    elsif ($action->{TYPE} eq "call") {
        print $out "$action->{TEXT}(";
        if (my @arguments = @{ $action->{ARGUMENTS} }) {
            print_argument($out, shift @arguments);
            for my $argument (@arguments) {
                print $out ", ";
                print_argument($out, $argument);
            }
        }
        print $out ")";
    }
}

sub print_argument
{
    my ($out, $argument) = @_;
    print $out "$argument->{TEXT}";
}

# ---------------------------------------------------------------------------
# Emit NatLink output

sub emit_output
{
    my ($out_file, @statements) = @_;
    open OUT, ">$out_file" or die "$@ $out_file";
    &emit_file_header;
    for my $statement (@statements) {
        my $type = $statement->{TYPE};
        if    ($type eq "definition") {emit_definition_grammar ($statement)}
        elsif ($type eq "command")    {emit_command_grammar ($statement)}
    }
    &emit_file_middle;
    &emit_context_setup;
    for my $statement (@statements) {
        my $type = $statement->{TYPE};
        if    ($type eq "definition") {emit_definition_actions ($statement)}
        elsif ($type eq "command")    {emit_top_command_actions ($statement)}
    }
    &emit_file_trailer;
    close OUT;
}

sub emit_context_setup
{
    # Build a list of context statements, and commands defined in each
    my (@contexts, $context);
    for my $statement (@_) {
        my $type = $statement->{TYPE};
        if ($type eq "context") {
            $context = $statement;
            push (@contexts, $context);
        } elsif ($type eq "command") {
            push (@{ $context->{RULENAMES} }, $statement->{NAME});
        }
    }
    emit_context_definitions(@contexts);
    emit_context_activations(@contexts);
}

sub emit_context_definitions
{
    # Emit a "rule set" definition containing all command names in this context
    my $number = 0;
    for my $context (@_) {
        my @names = @{ $context->{RULENAMES} };
        next if @names == 0;
        $number++;
        my $first_name = shift @names;
        print OUT "        self.ruleSet$number = ['$first_name'";
        for my $name (@names) {print OUT ",'$name'"}
        print OUT "]\n";
    }
}

sub emit_context_activations
{
    my $app = $Module_name;
    my $module_is_global = ($app =~ /^\_/);
    my $module_has_prefix = 0;
    if ($app =~ /^(.+?)_.*/) {
        $prefix = $1;
        $module_has_prefix = 1;
    }
    print OUT "        self.activateAll()\n" if $module_is_global;
    print OUT "\n    def gotBegin(self,moduleInfo):\n";
    if ($module_is_global) {
        print OUT "        window = moduleInfo[2]\n";
    } else {
        print OUT "        \# Return if wrong application\n";
        print OUT "        window = matchWindow(moduleInfo,'$app','')\n";
        if ($module_has_prefix) {
            print OUT "        if not window: window = matchWindow(moduleInfo,'$prefix','')\n";
        }
        print OUT "        if not window: return None\n";
    }
    print OUT "        self.sawResults = 0\n\n";
    print OUT "        \# Return if same window and title as before\n";
    print OUT "        if moduleInfo == self.currentModule: return None\n";
    print OUT "        self.currentModule = moduleInfo\n\n";
    print OUT "        self.deactivateAll()\n" unless $module_is_global;

    # Emit code to activate the context's commands if the context string
    # matches the current window
    my $number = 0;
    for my $context (@_) {
        next if not $context->{RULENAMES};
        $number++;
        next if $module_is_global and $number == 1;
        my $text = $context->{TEXT};
        print OUT "        if string.find(moduleInfo[1],'$text') >= 0:\n";
        print OUT "            for rule in self.ruleSet$number:\n";
        print OUT "                self.activate(rule,window)\n";
        if ($module_is_global) {
            print OUT "        else:\n";
            print OUT "            for rule in self.ruleSet$number:\n";
            print OUT "                if rule in self.activeRules:\n";
            print OUT "                    self.deactivate(rule,window)\n";
        }
    }
    print OUT "\n";
}

sub emit_definition_grammar
{
    my $definition = shift;
    print OUT "        <$definition->{NAME}> = ";
    emit_menu_grammar (@{ $definition->{MENU}->{COMMANDS} });
    print OUT ";\n";
}

sub emit_command_grammar
{
    my $command = shift;
    inline_a_term_if_nothing_concrete($command);
    print OUT "        <$command->{NAME}> exported = ";
    emit_command_terms (@{ $command->{TERMS} });
    print OUT ";\n";
}

sub emit_command_terms
{
    for my $term (@_) {
        if ($term->{OPTIONAL}) {print OUT "[ "}
        if ($term->{TYPE} eq "word") {
            my $word = $term->{TEXT};
            if ($word =~ /\'/) {print OUT '"', "$word", '" '}
            else               {print OUT "'$word' "}
        } elsif ($term->{TYPE} eq "variable") {print OUT "<$term->{TEXT}> "}
        elsif   ($term->{TYPE} eq "range")    {emit_range_grammar ($term)}
        elsif   ($term->{TYPE} eq "menu") {
            print OUT "(";
            emit_menu_grammar (@{ $term->{COMMANDS}} );
            print OUT ") ";
        }
        if ($term->{OPTIONAL}) {print OUT "] "}
    }
}

sub emit_menu_grammar
{
    emit_command_terms (@{ shift->{TERMS} });
    for my $command (@_) {
        print OUT "| ";
        emit_command_terms (@{ $command->{TERMS} });
    }
}

sub emit_range_grammar
{
    my $i  = @_[0]->{FROM};
    my $to = @_[0]->{TO};
    print OUT "($i";
    while (++$i <= $to) {print OUT " | $i"}
    print OUT ") ";
}

sub emit_definition_actions
{
    my $definition = shift;
    print OUT "    def do_$definition->{NAME}(self, word, output):\n";
    emit_menu_actions($definition->{MENU});
    print OUT "        return output\n\n"
}

sub emit_top_command_actions
{
    my $command = shift;
    my $command_id = $command->{NAME};
    my @terms = @{ $command->{TERMS} };
    print OUT "    \# ";
    print_terms (*OUT, @terms);
    print OUT "\n";
    print OUT "    def gotResults_$command_id(self, words, fullResults):\n";
    print OUT "        if self.sawResults: return None\n";
    print OUT "        self.sawResults = 1\n";
    print OUT "        output = ''\n";
    emit_optional_term_fixup(@terms);
    emit_command_actions($command);
}

# Our indexing into the "fullResults" array assumes all optional terms were 
# spoken.  So we emit code to insert a dummy entry for each optional word 
# that was not spoken.  (The strategy used could fail in the uncommon case 
# where an optional word is followed by an identical required word.)

sub emit_optional_term_fixup
{
    for my $term (@_) {
        if ($term->{OPTIONAL}) {
            my $index = $term->{NUMBER};
            my $text = $term->{TEXT};
            print OUT "        if $index < len(fullResults) and fullResults[$index][0] != '$text':\n";
            print OUT "            fullResults.insert($index, 'dummy')\n";
        }
    }   
}

sub emit_command_actions
{
    my $command = shift;
    # Get the variable terms now so they can be used in emit_reference
    @Command_variables = get_variable_terms($command);

    for my $action (@{ $command->{ACTIONS} }) {
        if ($action->{TYPE} eq "reference") {
            emit_reference($action);
        } else {
            emit_simple_action($action, "");
        }
    }
    print OUT "        if output: natlink.playString(output)\n\n";
}

sub get_variable_terms
{
    my $command = shift;
    my @variable_terms;
    for my $term (@{ $command->{TERMS} }) {
        my $type = $term->{TYPE};
        if ($type eq "menu" or $type eq "range" or $type eq "variable") {
            push (@variable_terms, $term);
        }
    }
    return @variable_terms;
}

sub emit_reference
{
    my $action = shift;
    my $reference_number = $action->{TEXT} - 1;
    my $variable = $Command_variables[$reference_number];
    my $term_number = $variable->{NUMBER};
    print OUT "        word = fullResults[$term_number][0]\n";
    if ($variable->{TYPE} eq "menu") {
        emit_menu_actions ($variable);
    } elsif ($variable->{TYPE} eq "range") {
        print OUT "        output = output + word\n";
    } elsif ($variable->{TYPE} eq "variable") {
        my $function = "self.do_$variable->{TEXT}";
        print OUT "        output = $function(word, output)\n";
    }
}

sub emit_menu_actions
{
    my $menu = shift;
    if (not menu_has_actions($menu)) {
        print OUT "        output = output + word\n";
    } else {
        my @commands = flatten_menu($menu);
        for my $command (@commands) {
            my $text = $command->{TERMS}[0]->{TEXT};
            $text =~ s/'/\\'/g;
            print OUT "        if word == '$text':\n";
            if (my @actions = @{ $command->{ACTIONS} }) {
                for my $action (@actions) {
                    emit_simple_action($action, "    ");
                }
            } else {
                print OUT "            output = output + '$text'\n";
            }
        }
    }
}

sub emit_simple_action
{
    my ($action, $indent) = @_;
    my $type = $action->{TYPE};
    if ($type eq "word") {
        my $safe_text = make_safe_python_string($action->{TEXT});
        print OUT "$indent        output = output + '$safe_text'\n";
    } elsif ($type eq "call") {
        &emit_call;
    } else {
        die "Unknown action type: '$type'\n";
    }
}

sub emit_call
{
    my ($action, $indent) = @_;
    my $call = $action->{TEXT};
    my @arguments = @{ $action->{ARGUMENTS} };
    print OUT "$indent        if output:\n";
    print OUT "$indent            natlink.playString(output)\n";  #!!!!
    print OUT "$indent            output = ''\n";
    if (all_words (@arguments)) {
        emit_simple_call($indent, $call, @arguments);
    } else {
        emit_call_with_variables($indent, $call, @arguments);
    }
}

sub all_words
{
    shift while @_ and $_[0]->{TYPE} eq "word";
    return (@_ == 0);
}

sub emit_simple_call
{
    my $indent = shift;
    my $call = shift;
    print OUT "$indent        natlink.execScript('$call ";
    while (my $argument = shift) {
        emit_simple_argument($argument);
        print OUT ", " if @_;
    }
    print OUT "')\n"; 
}

sub emit_simple_argument
{
    $text = shift->{TEXT};
    # Quote words, but not numbers
    if ($text =~ /^-?\d+$/) {print OUT      "$text"}
    else                    {print OUT '"', "$text", '"'}
}

sub emit_call_with_variables
{
    my $indent = shift;
    my $call = shift;
    print OUT "$indent        output = '$call '\n";
    while (my $argument = shift) {
        emit_argument($indent, $argument);
        print OUT "$indent        output = output + ', '\n" if @_;
    }
    print OUT "$indent        natlink.execScript(output)\n";
    print OUT "$indent        output = ''\n";
}

sub emit_argument
{
    my $indent = shift;
    my $argument = shift;
    if ($argument->{TYPE} eq "reference") {
        print OUT qq/$indent        output = output + '"'\n/;
        emit_reference($argument);
        print OUT qq/$indent        output = output + '"'\n/;
    } else {
        print OUT "$indent        output = output + '";
        emit_simple_argument($argument);
        print OUT "'\n";
    }
}

# ---------------------------------------------------------------------------
# Inlining
#
# If a command contains only variables, its callback function won't be invoked 
# by NatSpeak/NatLink.  We work around this annoyance by "inlining" variables
# (replacing a variable term with the variable's definition) until the command
# is "concrete" (all branches contain a non-optional word).

sub inline_a_term_if_nothing_concrete
{
    my $command = shift;
    while (!command_has_a_concrete_term($command)) {
        inline_a_term($command);
    }
}

sub command_has_a_concrete_term
{
    my $command = shift;
    for my $term (@{ $command->{TERMS} }) {
        my $type = $term->{TYPE};
        if ($type eq "menu") {
            return 1 if menu_is_concrete($term);
        } elsif ($type ne "variable") {
            return 1 unless $term->{OPTIONAL};
        }
    }
    return 0;
}

sub menu_is_concrete    # a menu is concrete if every command is concrete
{
    for my $command (@{ shift->{COMMANDS} }) {
        return 0 unless command_has_a_concrete_term($command);
    }
    return 1;
}

sub inline_a_term
{
    my $terms = shift->{TERMS};

    # Find the array index of the first non-optional term
    my $index = 0;
    $index++ while $index < @{$terms} and $terms->[$index]->{OPTIONAL};

    my $type = $terms->[$index]->{TYPE};
    my $number = $terms->[$index]->{NUMBER};
    if ($type eq "variable") {
        my $variable_name = $terms->[$index]->{TEXT};
        #print "inlining variable $variable_name\n";
        my $definition = $Definitions{$variable_name};
        $terms->[$index] = $definition->{MENU};
        $terms->[$index]->{NUMBER} = $number;
    } elsif ($type eq "menu") {
        for my $command (@{ $terms->[$index]->{COMMANDS} }) {
            inline_a_term($command);
        }
    } else {die "Internal error inlining term of type '$type'\n"}
}

# ---------------------------------------------------------------------------
# Utilities used by "emit" methods

sub menu_has_actions
{
    for my $command (@{ shift->{COMMANDS} }) {
        return 1 if $command->{ACTIONS};
        for $term (@{ $command->{TERMS} }) {
            return 1 if $term->{TYPE} eq "menu" and menu_has_actions($term);
        }
    }
    return;
}

# To emit actions for a menu, build a flat list of (canonicalized) commands:
#     - recursively extract commands from nested menus
#     - distribute actions, i.e. (day|days)=d --> (day=d|days=d)
# Note that error checking happened during parsing, in verify_referenced_menu

sub flatten_menu
{
    my ($menu, $actions_to_distribute) = @_;
    my (@new_commands, $new_actions);
    for my $command (@{ $menu->{COMMANDS} }) {
        if ($command->{ACTIONS}) {$new_actions = $command->{ACTIONS}}
        else                     {$new_actions = $actions_to_distribute}
        my @terms = @{ $command->{TERMS} };
        my $type = $terms[0]->{TYPE};
        if ($type eq "word") {
            $command->{ACTIONS} = $new_actions if $new_actions;
            push (@new_commands, $command);
        } elsif ($type eq "menu") {
            my @commands = flatten_menu ($terms[0], $new_actions);
            push (@new_commands, @commands);
        } 
    }
    return @new_commands;
}

sub make_safe_python_string
{
#    $_[0] =~ s/\\/\\\\/g;      # 5/3/2002 now doing this up front
    $_[0] =~ s/'/\\'/g;
    return $_[0];
}

# ---------------------------------------------------------------------------
# Pieces of the output Python file

sub emit_file_header
{
    $now = localtime;
    print OUT "\# NatLink macro definitions for NaturallySpeaking\n"; 
    print OUT "\# Generated by vcl2py $VocolaVersion, $now\n";
    print OUT <<MARK;

import natlink
from natlinkutils import *

class ThisGrammar(GrammarBase):

    gramSpec = """
MARK
}

sub emit_file_middle
{
    print OUT <<MARK;
    """
    
    def initialize(self):
        self.load(self.gramSpec)
        self.currentModule = ("","",0)
MARK
}

sub emit_file_middle_for_global_commands
{
    print OUT <<MARK;
    """
    
    def initialize(self):
        self.load(self.gramSpec)
        self.activateAll()

    def gotBegin(self, moduleInfo):
        self.sawResults = 0

MARK
}

sub emit_file_trailer
{
    print OUT <<MARK;
thisGrammar = ThisGrammar()
thisGrammar.initialize()

def unload():
    global thisGrammar
    if thisGrammar: thisGrammar.unload()
    thisGrammar = None
MARK
}
