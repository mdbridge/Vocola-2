Place your Vocola 2 extension files in this directory.

See http://vocola.net/v2/UsingExtensions.asp for more information.
